package com.example.demo.constant;

/**
 * 业务常量类 - 集中管理所有魔法字
 * 解决代码中意义不明的硬编码数字问题
 */
public class BusinessConstants {

    // ==================== 合同状态 ====================
    public static final int CONTRACT_DRAFT = 0;         // 草稿
    public static final int CONTRACT_PENDING = 1;        // 待确认
    public static final int CONTRACT_ACTIVE = 2;         // 生效中
    public static final int CONTRACT_EXPIRED = 3;         // 已到期
    public static final int CONTRACT_TERMINATED = 4;     // 已终止

    // ==================== 评论状态 ====================
    public static final int COMMENT_NORMAL = 0;   // 正常
    public static final int COMMENT_DELETED = 1;  // 已删除

    // ==================== 举报状态 ====================
    public static final int REPORT_PENDING = 0;   // 待处理


    private BusinessConstants() {
        // 防止实例化
    }
}
