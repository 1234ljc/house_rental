package com.example.demo.service.rental.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.constant.BusinessConstants;
import com.example.demo.entity.Result;
import com.example.demo.repository.house.entity.House;
import com.example.demo.repository.house.HouseMapper;
import com.example.demo.service.notification.NotificationService;
import com.example.demo.repository.rental.entity.RentalContract;
import com.example.demo.repository.rental.entity.RentalManage;
import com.example.demo.repository.rental.RentalContractMapper;
import com.example.demo.repository.rental.RentalManageMapper;
import com.example.demo.service.rental.LandlordAfterService;
import com.example.demo.repository.user.entity.User;
import com.example.demo.repository.user.UserMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.*;

@Service
// 负责房东侧当前租客、历史租客、报修工单和退租处理功能实现
public class LandlordAfterServiceImpl implements LandlordAfterService {

    private final RentalManageMapper rentalManageMapper;
    private final RentalContractMapper rentalContractMapper;
    private final HouseMapper houseMapper;
    private final UserMapper userMapper;
    private final NotificationService notificationService;

    public LandlordAfterServiceImpl(RentalManageMapper rentalManageMapper,
                                    RentalContractMapper rentalContractMapper,
                                    HouseMapper houseMapper,
                                    UserMapper userMapper,
                                    NotificationService notificationService) {
        this.rentalManageMapper = rentalManageMapper;
        this.rentalContractMapper = rentalContractMapper;
        this.houseMapper = houseMapper;
        this.userMapper = userMapper;
        this.notificationService = notificationService;
    }

    // 当前租客列表：查看正在生效合同对应的租客，便于后续沟通和履约
    @Override
    public Result getCurrentTenants(HttpServletRequest request) {
        Long landlordId = (Long) request.getAttribute("userId");
        LambdaQueryWrapper<RentalContract> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(RentalContract::getLandlordId, landlordId).eq(RentalContract::getStatus, 2).orderByDesc(RentalContract::getCreateTime);
        List<RentalContract> contracts = rentalContractMapper.selectList(wrapper);
        List<Map<String, Object>> result = new ArrayList<>();
        for (RentalContract contract : contracts) {
            result.add(buildTenantInfo(contract));
        }
        return Result.success(result);
    }

    // 历史租客列表：查看已到期或已终止合同中的租客记录
    @Override
    public Result getHistoryTenants(Integer page, Integer size, HttpServletRequest request) {
        Long landlordId = (Long) request.getAttribute("userId");
        Page<RentalContract> pageParam = new Page<>(page, size);
        LambdaQueryWrapper<RentalContract> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(RentalContract::getLandlordId, landlordId).in(RentalContract::getStatus, Arrays.asList(3, 4)).orderByDesc(RentalContract::getUpdateTime);
        Page<RentalContract> result = rentalContractMapper.selectPage(pageParam, wrapper);
        List<Map<String, Object>> records = new ArrayList<>();
        for (RentalContract contract : result.getRecords()) {
            records.add(buildTenantInfo(contract));
        }
        return Result.success(Map.of("records", records, "total", result.getTotal()));
    }

    // 租客详情：查看特定合同的详细信息
    @Override
    public Result getTenantDetail(Long contractId, HttpServletRequest request) {
        Long landlordId = (Long) request.getAttribute("userId");
        RentalContract contract = rentalContractMapper.selectById(contractId);
        if (contract == null) {
            return Result.error("合同不存在");
        }
        if (!contract.getLandlordId().equals(landlordId)) {
            return Result.error("无权查看此合同");
        }
        Map<String, Object> detail = buildTenantInfo(contract);

        // 获取房源信息
        House house = houseMapper.selectById(contract.getHouseId());
        if (house != null) {
            detail.put("houseTitle", house.getTitle());
            detail.put("houseAddress", house.getAddress());
            detail.put("houseImage", house.getImage());
        }

        // 获取租客详细信息
        User tenant = userMapper.selectById(contract.getTenantId());
        if (tenant != null) {
            detail.put("tenantUsername", tenant.getUsername());
            detail.put("tenantPhone", tenant.getPhone());
            detail.put("tenantRealName", tenant.getRealName());
            detail.put("tenantIdCard", tenant.getIdCard());
        }

        return Result.success(detail);
    }

    // 报修工单列表
    @Override
    public Result getIssueList(Integer status, Long houseId, Integer page, Integer size, HttpServletRequest request) {
        Long landlordId = (Long) request.getAttribute("userId");
        Page<RentalManage> pageParam = new Page<>(page, size);
        LambdaQueryWrapper<RentalManage> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(RentalManage::getLandlordId, landlordId);
        if (status != null) {
            wrapper.eq(RentalManage::getStatus, status);
        }
        if (houseId != null) {
            wrapper.eq(RentalManage::getHouseId, houseId);
        }
        wrapper.eq(RentalManage::getType, BusinessConstants.MANAGE_TYPE_REPAIR);
        wrapper.orderByDesc(RentalManage::getCreateTime);
        Page<RentalManage> result = rentalManageMapper.selectPage(pageParam, wrapper);

        List<Map<String, Object>> records = new ArrayList<>();
        for (RentalManage manage : result.getRecords()) {
            Map<String, Object> record = new HashMap<>();
            record.put("manageId", manage.getId());
            record.put("houseId", manage.getHouseId());
            record.put("status", manage.getStatus());
            record.put("description", manage.getDescription());
            record.put("createTime", manage.getCreateTime());
            record.put("updateTime", manage.getUpdateTime());

            // 获取房源信息
            House house = houseMapper.selectById(manage.getHouseId());
            if (house != null) {
                record.put("houseAddress", house.getAddress());
            }

            records.add(record);
        }

        return Result.success(Map.of("records", records, "total", result.getTotal()));
    }

    // 发起退租流程
    @Override
    @Transactional
    public Result processCheckout(Long manageId, HttpServletRequest request) {
        Long landlordId = (Long) request.getAttribute("userId");
        RentalManage manage = rentalManageMapper.selectById(manageId);
        if (manage == null) {
            return Result.error("工单不存在");
        }
        if (!manage.getLandlordId().equals(landlordId)) {
            return Result.error("无权操作此工单");
        }

        manage.setStatus(BusinessConstants.MANAGE_STATUS_PENDING);
        manage.setUpdateTime(LocalDateTime.now());
        rentalManageMapper.updateById(manage);

        return Result.success("退租流程已发起");
    }

    // 审核退租申请
    @Override
    @Transactional
    public Result auditCheckout(Long manageId, Map<String, Object> params, HttpServletRequest request) {
        Long landlordId = (Long) request.getAttribute("userId");
        RentalManage manage = rentalManageMapper.selectById(manageId);
        if (manage == null) {
            return Result.error("工单不存在");
        }
        if (!manage.getLandlordId().equals(landlordId)) {
            return Result.error("无权操作此工单");
        }

        Integer auditResult = (Integer) params.get("result"); // 1通过 2拒绝
        if (auditResult == null) {
            return Result.error("请输入审核结果");
        }

        if (auditResult == 1) {
            manage.setStatus(BusinessConstants.MANAGE_STATUS_APPROVED);
        } else if (auditResult == 2) {
            manage.setStatus(BusinessConstants.MANAGE_STATUS_REJECTED);
        } else {
            return Result.error("无效的审核结果");
        }

        manage.setUpdateTime(LocalDateTime.now());
        rentalManageMapper.updateById(manage);

        // 发送通知给租客
        notificationService.sendNotification(
            manage.getTenantId(),
            "退租审核结果",
            auditResult == 1 ? "您的退租申请已通过" : "您的退租申请被拒绝"
        );

        return Result.success(auditResult == 1 ? "审核通过" : "审核已拒绝");
    }

    // 安排交接
    @Override
    @Transactional
    public Result arrangeHandover(Long manageId, Map<String, Object> params, HttpServletRequest request) {
        Long landlordId = (Long) request.getAttribute("userId");
        RentalManage manage = rentalManageMapper.selectById(manageId);
        if (manage == null) {
            return Result.error("工单不存在");
        }
        if (!manage.getLandlordId().equals(landlordId)) {
            return Result.error("无权操作此工单");
        }

        String handoverTime = (String) params.get("handoverTime");
        String handoverLocation = (String) params.get("handoverLocation");

        if (handoverTime == null || handoverLocation == null) {
            return Result.error("请填写交接时间和地点");
        }

        manage.setStatus(BusinessConstants.MANAGE_STATUS_IN_PROGRESS);
        manage.setUpdateTime(LocalDateTime.now());
        rentalManageMapper.updateById(manage);

        // 发送通知给租客
        notificationService.sendNotification(
            manage.getTenantId(),
            "退租交接安排",
            "交接时间：" + handoverTime + "，交接地点：" + handoverLocation
        );

        return Result.success("交接安排已发送");
    }

    // 完成退租
    @Override
    @Transactional
    public Result completeCheckout(Long manageId, Map<String, Object> params, HttpServletRequest request) {
        Long landlordId = (Long) request.getAttribute("userId");
        RentalManage manage = rentalManageMapper.selectById(manageId);
        if (manage == null) {
            return Result.error("工单不存在");
        }
        if (!manage.getLandlordId().equals(landlordId)) {
            return Result.error("无权操作此工单");
        }

        manage.setStatus(BusinessConstants.MANAGE_STATUS_COMPLETED);
        manage.setUpdateTime(LocalDateTime.now());
        rentalManageMapper.updateById(manage);

        // 如果有合同ID，同步更新合同状态
        Long contractId = manage.getContractId();
        if (contractId != null) {
            RentalContract contract = rentalContractMapper.selectById(contractId);
            if (contract != null) {
                contract.setStatus(BusinessConstants.CONTRACT_STATUS_TERMINATED);
                contract.setUpdateTime(LocalDateTime.now());
                rentalContractMapper.updateById(contract);
            }
        }

        // 发送通知给租客
        notificationService.sendNotification(
            manage.getTenantId(),
            "退租完成",
            "您的退租流程已完成，感谢您的使用"
        );

        return Result.success("退租已完成");
    }

    /**
     * 构建租客信息
     */
    private Map<String, Object> buildTenantInfo(RentalContract contract) {
        Map<String, Object> info = new HashMap<>();
        info.put("contractId", contract.getContractId());
        info.put("tenantId", contract.getTenantId());
        info.put("startDate", contract.getStartDate());
        info.put("endDate", contract.getEndDate());
        info.put("status", contract.getStatus());

        // 获取房源信息
        House house = houseMapper.selectById(contract.getHouseId());
        if (house != null) {
            info.put("houseAddress", house.getAddress());
        }

        // 获取租客信息
        User tenant = userMapper.selectById(contract.getTenantId());
        if (tenant != null) {
            info.put("tenantName", tenant.getRealName());
            info.put("tenantPhone", tenant.getPhone());
        }

        return info;
    }
}
