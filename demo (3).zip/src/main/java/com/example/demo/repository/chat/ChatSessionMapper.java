package com.example.demo.repository.chat;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.repository.chat.entity.ChatSession;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface ChatSessionMapper extends BaseMapper<ChatSession> {

    /**
     * 获取用户的会话列表（带房源和对方用户信息）- 只查普通会话
     */
    @Select("""
        SELECT cs.*, 
               h.title as house_title, h.images as house_images, 
               u_landlord.username as landlord_name, u_landlord.avatar as landlord_avatar,
               u_tenant.username as tenant_name, u_tenant.avatar as tenant_avatar,
               cs.unread_landlord as unread_count
        FROM chat_session cs
        LEFT JOIN house h ON cs.house_id = h.house_id
        LEFT JOIN `user` u_landlord ON cs.landlord_id = u_landlord.user_id
        LEFT JOIN `user` u_tenant ON cs.tenant_id = u_tenant.user_id
        WHERE cs.session_type = 0 OR cs.session_type IS NULL
          AND ((cs.landlord_id = #{userId} AND #{userType} = 2) OR (cs.tenant_id = #{userId} AND #{userType} = 1))
          AND cs.status = 0
        ORDER BY cs.update_time DESC
        LIMIT #{offset}, #{size}
    """)
    List<Map<String, Object>> getSessionListByUser(@Param("userId") Long userId, 
                                                   @Param("userType") Integer userType,
                                                   @Param("offset") Integer offset,
                                                   @Param("size") Integer size);

    /**
     * 统计用户会话总数
     */
    @Select("""
        SELECT COUNT(*) FROM chat_session 
        WHERE (session_type = 0 OR session_type IS NULL)
          AND ((landlord_id = #{userId} AND #{userType} = 2) OR (tenant_id = #{userId} AND #{userType} = 1))
          AND status = 0
    """)
    Long countByUser(@Param("userId") Long userId, @Param("userType") Integer userType);

    /**
     * 统计用户未读消息总数
     */
    @Select("""
        SELECT COALESCE(
            (SELECT SUM(unread_tenant) FROM chat_session WHERE tenant_id = #{userId} AND session_type = 0 LIMIT 1) +
            (SELECT SUM(unread_admin) FROM chat_session WHERE customer_id = #{userId} AND session_type = 1 LIMIT 1),
            0
        )
    """)
    Long countTotalUnread(@Param("userId") Long userId);

    /**
     * 清除用户未读消息数
     */
    @Update("""
        UPDATE chat_session 
        SET unread_tenant = 0, unread_customer = 0
        WHERE session_id = #{sessionId}
    """)
    int clearUnread(@Param("sessionId") Long sessionId);

    /**
     * 增加会话未读数
     */
    @Update("""
        UPDATE chat_session 
        SET unread_tenant = unread_tenant + CASE WHEN #{senderType} = 1 THEN 1 ELSE 0 END,
            unread_landlord = unread_landlord + CASE WHEN #{senderType} = 2 THEN 1 ELSE 0 END,
            last_message = #{lastMessage},
            last_message_time = NOW()
        WHERE session_id = #{sessionId}
    """)
    int incrementUnread(@Param("sessionId") Long sessionId, 
                        @Param("senderType") Integer senderType,
                        @Param("lastMessage") String lastMessage);

    /**
     * 查找已存在的会话
     */
    @Select("""
        SELECT * FROM chat_session 
        WHERE house_id = #{houseId} AND landlord_id = #{landlordId} AND tenant_id = #{tenantId}
        LIMIT 1
    """)
    ChatSession findExistingSession(@Param("houseId") Long houseId, 
                                    @Param("landlordId") Long landlordId, 
                                    @Param("tenantId") Long tenantId);

    /**
     * 查找客服会话
     */
    @Select("""
        SELECT * FROM chat_session 
        WHERE customer_id = #{userId} AND session_type = 1
        LIMIT 1
    """)
    ChatSession findCustomerServiceSession(@Param("userId") Long userId);

    /**
     * 查找已关闭的客服会话
     */
    @Select("""
        SELECT * FROM chat_session 
        WHERE customer_id = #{userId} AND session_type = 1 AND status = 1
        LIMIT 1
    """)
    ChatSession findClosedCustomerServiceSession(@Param("userId") Long userId);

    /**
     * 获取客服会话列表（按管理员）
     */
    @Select("""
        SELECT cs.*, 
               u_customer.username as customer_username, 
               u_customer.avatar as customer_avatar,
               u_customer.user_type as customer_type,
               cs.unread_admin as unread_count
        FROM chat_session cs
        LEFT JOIN `user` u_customer ON cs.customer_id = u_customer.user_id
        WHERE cs.session_type = 1 AND cs.service_admin_id = #{adminId} AND cs.status = #{status}
        ORDER BY cs.update_time DESC
        LIMIT #{offset}, #{size}
    """)
    List<Map<String, Object>> getCustomerServiceSessionsByAdmin(@Param("adminId") Long adminId,
                                                                 @Param("status") Integer status,
                                                                 @Param("offset") Integer offset,
                                                                 @Param("size") Integer size);

    /**
     * 统计管理员的客服会话数
     */
    @Select("""
        SELECT COUNT(*) FROM chat_session 
        WHERE session_type = 1 AND service_admin_id = #{adminId} AND status = #{status}
    """)
    Long countCustomerServiceByAdmin(@Param("adminId") Long adminId, @Param("status") Integer status);

    /**
     * 统计待接入的客服会话数
     */
    @Select("""
        SELECT COUNT(*) FROM chat_session 
        WHERE session_type = 1 AND service_admin_id IS NULL AND status = 0
    """)
    Long countPendingCustomerService();

    /**
     * 统计用户未读消息数
     */
    @Select("""
        SELECT COALESCE(
            (SELECT unread_tenant FROM chat_session WHERE house_id = #{userId} AND session_type = 0 LIMIT 1) +
            (SELECT unread_customer FROM chat_session WHERE customer_id = #{userId} AND session_type = 1 LIMIT 1),
            0
        )
    """)
    Long countUnreadByUser(@Param("userId") Long userId);

    /**
     * 标记会话已读
     */
    @Update("""
        UPDATE chat_session 
        SET unread_tenant = 0 
        WHERE session_id = #{sessionId} AND #{userType} = 1
    """)
    int markRead(@Param("sessionId") Long sessionId, @Param("userType") Integer userType);

    /**
     * 根据用户ID查找客服会话
     */
    @Select("""
        SELECT * FROM chat_session 
        WHERE customer_id = #{userId} AND session_type = 1
        LIMIT 1
    """)
    ChatSession selectByCustomerServiceSession(@Param("userId") Long userId);

    /**
     * 根据用户ID和类型查找客服会话列表
     */
    @Select("""
        SELECT * FROM chat_session 
        WHERE customer_id = #{userId} AND customer_type = #{customerType} AND session_type = 1
    """)
    List<ChatSession> selectByCustomerServiceSession(@Param("userId") Long userId, @Param("customerType") Integer customerType);

    /**
     * 根据房源和用户查找会话
     */
    @Select("""
        SELECT * FROM chat_session 
        WHERE house_id = #{houseId} AND tenant_id = #{userId}
        LIMIT 1
    """)
    ChatSession selectByHouseAndUser(@Param("houseId") Long houseId, @Param("userId") Long userId);

    /**
     * 更新会话最后一条消息
     */
    @Update("""
        UPDATE chat_session 
        SET last_message = #{lastMessage}, last_message_time = NOW()
        WHERE session_id = #{sessionId}
    """)
    int updateLastMessage(@Param("sessionId") Long sessionId, @Param("lastMessage") String lastMessage);

    /**
     * 更新会话最后消息时间
     */
    @Update("""
        UPDATE chat_session 
        SET last_message_time = NOW()
        WHERE session_id = #{sessionId}
    """)
    int updateLastMessageTime(@Param("sessionId") Long sessionId);

    /**
     * 清除客服会话未读数
     */
    @Update("""
        UPDATE chat_session 
        SET unread_customer = 0, unread_admin = 0
        WHERE session_id = #{sessionId}
    """)
    int clearCustomerServiceUnread(@Param("sessionId") Long sessionId);

    /**
     * 增加客服会话未读数
     */
    @Update("""
        UPDATE chat_session 
        SET unread_customer = unread_customer + CASE WHEN #{isFromAdmin} = 1 THEN 1 ELSE 0 END,
            unread_admin = unread_admin + CASE WHEN #{isFromAdmin} = 0 THEN 1 ELSE 0 END,
            last_message = #{lastMessage},
            last_message_time = NOW()
        WHERE session_id = #{sessionId}
    """)
    int incrementCustomerServiceUnread(@Param("sessionId") Long sessionId,
                                        @Param("isFromAdmin") Integer isFromAdmin,
                                        @Param("lastMessage") String lastMessage);

    /**
     * 接入客服会话
     */
    @Update("""
        UPDATE chat_session 
        SET service_admin_id = #{adminId}
        WHERE session_id = #{sessionId} AND session_type = 1
    """)
    int acceptCustomerService(@Param("sessionId") Long sessionId, @Param("adminId") Long adminId);

    /**
     * 关闭客服会话
     */
    @Update("""
        UPDATE chat_session 
        SET status = 1
        WHERE session_id = #{sessionId} AND session_type = 1
    """)
    int closeCustomerService(@Param("sessionId") Long sessionId);

    /**
     * 统计指定房源的咨询量
     */
    @Select("SELECT COUNT(*) FROM chat_session WHERE house_id = #{houseId} AND (session_type = 0 OR session_type IS NULL)")
    Long countConsultByHouseId(@Param("houseId") Long houseId);

    /**
     * 获取排队位置
     */
    @Select("""
        SELECT COUNT(*) + 1 FROM chat_session 
        WHERE session_type = 1 AND service_admin_id IS NULL AND status = 0 
          AND update_time < (SELECT update_time FROM chat_session WHERE session_id = #{sessionId})
    """)
    Long getQueuePosition(@Param("sessionId") Long sessionId);

    /**
     * 统计管理员未读数
     */
    @Select("""
        SELECT COALESCE(SUM(unread_admin), 0) FROM chat_session 
        WHERE service_admin_id = #{adminId} AND status = 0
    """)
    Long countAdminUnread(@Param("adminId") Long adminId);

    /**
     * 获取待接入的客服会话列表（按等待时间排序，最久的排最前）
     */
    @Select("""
        SELECT cs.*, 
               u_customer.username as customer_username, 
               u_customer.avatar as customer_avatar,
               u_customer.user_type as customer_type,
               cs.unread_admin as unread_count
        FROM chat_session cs
        LEFT JOIN `user` u_customer ON cs.customer_id = u_customer.user_id
        WHERE cs.session_type = 1 AND cs.service_admin_id IS NULL AND cs.status = 0
        ORDER BY cs.update_time ASC
        LIMIT #{offset}, #{size}
    """)
    List<Map<String, Object>> getPendingCustomerServiceSessions(@Param("offset") Integer offset,
                                                                @Param("size") Integer size);
}
