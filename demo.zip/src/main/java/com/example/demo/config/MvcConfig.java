package com.example.demo.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Slf4j
@Configuration
public class MvcConfig implements WebMvcConfigurer {

    @Value("${upload.save-path}")
    private String savePath;

    @Value("${upload.mapping}")
    private String mapping;

    @Autowired
    private JwtInterceptor jwtInterceptor;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 原有的upload映射
        String location = System.getProperty("os.name").toLowerCase().contains("win")
                ? "file:///" + savePath.replace("\\", "/")
                : "file:" + savePath;
        log.info("注册资源映射: {} -> {}", mapping, location);
        registry.addResourceHandler(mapping)
                .addResourceLocations(location);
        
        // 添加uploads目录映射（用于聊天文件、合同等）
        String uploadsPath = System.getProperty("user.dir") + "/uploads/";
        String uploadsLocation = System.getProperty("os.name").toLowerCase().contains("win")
                ? "file:///" + uploadsPath.replace("\\", "/")
                : "file:" + uploadsPath;
        log.info("注册uploads资源映射: /uploads/** -> {}", uploadsLocation);
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations(uploadsLocation);
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(jwtInterceptor)
                .addPathPatterns("/api/**")
                .excludePathPatterns("/api/auth/**");
    }
}